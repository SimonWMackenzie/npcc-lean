import Tests.DigitEncoding
